export const WHITE = '#FFFFFF'
export const BORDER = 'rgba(0, 0, 0, 0.05)'

export const LIGHT_BLUE = '#e5f0ff'
export const BLUE = '#cce1ff'

export const LIGHT_RED = '#ffe5e5'
export const RED = '#ffccd5'

export const SQUARE_SIZE = 1
